/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcsample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Bryant
 */
public class AdminChangeDB {
    private static final String USERNAME = "root"; //insert username for DB
    private static final String PASSWORD = "pass"; //insert pass for DB
    private static final String CONN = "jdbc:mysql://localhost:3306/change?autoReconnect=true&useSSL=false";

    public static Connection getconnection() throws SQLException{
        System.out.println("AdminDB connected");
        return DriverManager.getConnection(CONN, USERNAME, PASSWORD);
    }
}
